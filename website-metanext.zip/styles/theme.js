export const palletColor = {
  color_primary: "#053EFF",
  color_gray: "#6F6F6F",
};
