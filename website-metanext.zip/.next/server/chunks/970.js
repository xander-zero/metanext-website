"use strict";
exports.id = 970;
exports.ids = [970];
exports.modules = {

/***/ 5658:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const HeaderTitle = ({ size , color , children , weight , en  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Text, {
        size: size,
        color: color,
        weight: weight,
        en: en,
        children: children
    });
};
const Text = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1)`
  font-size: ${({ size  })=>size};
  color: ${({ color  })=>color ? color : "#053EFF"};
  font-weight: bold;
  font-family: ${({ en  })=>en ? "sans-serif" : ""};
  @media (max-width: 768px) {
    font-size: 20px;
  }

  @media (max-width: 568px) {
    font-size: 18px;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderTitle);


/***/ }),

/***/ 2939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useWindowSize)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useWindowSize() {
    // Initialize state with undefined width/height so server and client renders match
    // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
    const { 0: windowSize , 1: setWindowSize  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        width: undefined,
        height: undefined
    });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // only execute all the code below in client side
        if (false) {}
    }, []); // Empty array ensures that effect is only run on mount
    return windowSize;
};


/***/ }),

/***/ 3369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pk": () => (/* binding */ WrapperText),
/* harmony export */   "ZL": () => (/* binding */ GlobalStyle)
/* harmony export */ });
/* unused harmony exports Wrapper, HeaderTitle */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);


const GlobalStyle = styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle`
    body{
        margin:0;
        padding:0;
        box-sizing:border-box;
        direction:rtl;
        font-family:'IRANSans' !important;
        overflow-x:hidden;
    }
    h1,h2,h3,h4,h5,h6,p{
        margin:0;
        padding:0
    }
    ul{
        list-style:none
    }
    a{
        text-decoration:none !important;
        
    }

    .label-request{
      font-size:14px;
    }
    .label-request{
      @media (max-width:567px){
        font-size:12px
      }
    }
`;
const Wrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  justify-content: ${({ postion  })=>postion ? postion : ""};
  flex-wrap: wrap;
  align-items: center;
  margin-top: 1rem;

  @media (max-width: 995px) {
    justify-content: center !important;
  }
`;
const HeaderTitle = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2)`
  color: ${({ color  })=>color};
  font-weight: ${({ weight  })=>weight};
  font-size: ${({ size  })=>size};
  text-align: ${({ textAlign  })=>textAlign ? textAlign : ""};
  font-family: ${({ en  })=>en ? "Arial" : "IRANSans"};
  font-weight: bold !important;
  /* letter-spacing: -0.1rem; */
  /* line-height: 3rem; */
  @media (max-width: 768px) {
    font-size: 25px;
  }
`;
const WrapperText = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: ${({ width  })=>width};
  margin: ${({ margin  })=>`1rem ${margin}`};

  @media (max-width: 560px) {
    width: 100%;
  }
`;


/***/ })

};
;