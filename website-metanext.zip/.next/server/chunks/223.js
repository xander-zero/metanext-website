"use strict";
exports.id = 223;
exports.ids = [223];
exports.modules = {

/***/ 7252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const Button = ({ children , bgColor , color , radius , width , size  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Btn, {
        bgColor: bgColor,
        color: color,
        radius: radius,
        width: width,
        size: size,
        children: children
    });
};
const Btn = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().button)`
  background-color: ${({ bgColor  })=>bgColor ? bgColor : "#fff"};
  color: ${({ color  })=>color ? color : "#000"};
  /* border-radius: ${({ radius  })=>radius ? "50px" : "10px"}; */
  border-radius: 100px;
  box-shadow: 0px 3px 6px rgba(5, 62, 255, 0.2);
  font-size: ${({ size  })=>size ? size : "15px"};
  border: none;
  outline: none;
  padding: 0.5rem 1rem;
  width: ${({ width  })=>width};

  a {
    color: ${({ color  })=>color};
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 4405:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const Typography = ({ children , size , color , weight , textAlign , en , height ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Text, {
        size: size,
        color: color,
        weight: weight,
        textAlign: textAlign,
        en: en,
        height: height,
        children: children
    });
};
const Text = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().p)`
  color: ${({ color  })=>color ? color : "#6F6F6F"};
  font-size: ${({ size  })=>size ? size : "14px"};
  font-weight: ${({ weight  })=>weight ? weight : ""};
  line-height: ${({ height  })=>height ? "25px" : "35px"};
  text-align: ${({ textAlign  })=>textAlign};
  font-family: ${({ en  })=>en ? "sans-serif" : "IRANSans"};

  @media (max-width: 768px) {
    font-size: 16px !important;
  }

  @media (max-width: 568px) {
    font-size: 14px !important;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Typography);


/***/ })

};
;