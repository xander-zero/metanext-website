(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.1a84a9f8.png","height":189,"width":785,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATElEQVR4nGOsa37ygomJ8UFD9dd0KSNmwTc/GJj/Mfz/wsDAyMjAwMDJ2NT29PmfP/8fNtV9TZEzYRF6/o3h93+G/8xABUwMDP9/AgCS0BuQF/bETAAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 24:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./common/Typography/Typography.jsx
var Typography = __webpack_require__(4405);
// EXTERNAL MODULE: ./components/HeaderTitle/HeaderTitle.jsx
var HeaderTitle = __webpack_require__(5658);
// EXTERNAL MODULE: ./styles/GlobalStyle.js
var GlobalStyle = __webpack_require__(3369);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./common/Footer/footerStyle.js

const FooterStyle = (external_styled_components_default()).div`
  background: #f3f7fc;
  margin-top: 5rem;
  padding: 2rem 0 0 0;
  position: relative;
  @media (max-width: 567px) {
    margin-top: 4rem;
  }

  .line {
    position: absolute;
    width: 2px;
    height: 60%;
    background-color: #d4deff;
    left: 0;
    right: 0;
    margin: auto;
    top: 0;
    bottom: 0;

    @media (max-width: 768px) {
      display: none;
    }
  }
`;
const Wrapper = (external_styled_components_default()).div`
  display: flex;
  align-items: center;
  justify-content: center;
`;
const Right = (external_styled_components_default()).div`
  width: 50%;
  @media (max-width: 768px) {
    display: none;
  }
`;
const Left = (external_styled_components_default()).div`
  width: 50%;
  display: flex;
  flex-direction: column;
  padding: 0 6rem;
  @media (max-width: 768px) {
    width: 100%;
    padding: 0;
  }
`;
const SocilaMedia = (external_styled_components_default()).div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
`;
const Icon = (external_styled_components_default()).div`
  margin: 0 0.5rem;
`;
const List = (external_styled_components_default()).ul`
  display: flex;
  flex-direction: column;
  padding: 0;
`;
const ListItem = (external_styled_components_default()).li`
  display: flex;
  flex-direction: column;
  margin: 0.7rem 0;
`;
const WrapperIcon = (external_styled_components_default()).div`
  display: flex;
  align-items: center;
`;
const WapperIcon = (external_styled_components_default()).div`
  display: flex;
  justify-content: center;
  /* margin-bottom: 20px; */
  position: absolute;
  width: 100px;
  height: 80px;
  left: 0;
  right: 0;
  margin: 0 auto;
  top: -40px;
  transition: 0.4s all ease-in-out;
  &:hover {
    transform: translateY(-10px);
    cursor: pointer;
  }

  img {
    cursor: pointer;
    box-shadow: 0px 7px 25px rgba(5, 62, 255, 0.08);
  }
`;
const SubFooter = (external_styled_components_default()).div`
  border-top: 1px solid #d4deff;
  padding: 1rem;

  @media (max-width: 768px) {
    display: none;
  }
`;

;// CONCATENATED MODULE: ./public/assets/images/phone.png
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.500e304e.png","height":23,"width":23,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA40lEQVR42iWOPU7DQBCFp+IUIAUJUXAfCq5AQ8clEDU9ElUEpKGIBEoFogIhCkSBsRfjrO1snCLZmc2PX2aT4mvme09vCACZWjqm4l5WSZmP2NqGu1kpe9FFua8YlVCJ71zw/iPQW2LqsEtZxQ9R/loJRcPt5e2y3TlvQ2JjQboxMDM1Y9gw3JRx/bjA8cWqzR1DizWp9DF9/zzH4CPg9GqF3sscdsJIS3akD/XfdJNOEOgMuHlaoBhziLPKHRVjf5hYHr5+BXymspnaSv5TOgSAcuePygkP/h37tBKvoq8cAKA1MPDbFze+C6kAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/images/location.png
/* harmony default export */ const images_location = ({"src":"/_next/static/media/location.4fc8011f.png","height":23,"width":23,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42h2NPUoEQRCF6wLeQGEFMfAypp5DMDQURFjBM5go/rCJgZEmirHBqiA6s+3sON2z6w+4VQW986zahg8erx9fUWiFjF7RyOCj5cb4tHwWkqyQv1Erq2WUUTVhPAXBSyXwbN1bSLpMtr6qpoz7oermwbzbOpx3D8+qPnITvTfyF38Z/fOM/kXG/mnG0SB38Ydhf4mKKLPaDLePCtoGlnY63A0V46kbeEJl5Gu7h/EX6+5xxt5JRv3N6p1xSWXidRvVoWW81gLHs3XB6PnA2Sgi34TEM6dYWHmNiOgfjAnUUX5jXpQAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/images/email.png
/* harmony default export */ const email = ({"src":"/_next/static/media/email.8da62903.png","height":23,"width":23,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2klEQVR42h3KsS4EURyF8e/cmbkVyTZCI1nZREGjEwXZSiF6D6HzDnoNjVfQeoDJaHgAhQgSG0IkQmF2r3vvfyfzq05yPgG8fE6HZpwJdgAzaJw4AV7VnWtO1L60VTl6KUGMekba0+SrvW6DDu4eijCbUZnB0sD+t0bJm+mqlBi3Ae7f5L9/RQZGy7naHApfMHbOob+pOL0pSBnef+DitlBKIJkrc6YZLNj+5WEMKcpng6PFHHxFt1Xr6aNdrwrqqmRFomcZQmSSM7sC6KINmc4lto1eI+wYeJwDNeFeBFseQ74AAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./public/assets/images/logo.png
var logo = __webpack_require__(873);
;// CONCATENATED MODULE: ./public/assets/images/upIcon.png
/* harmony default export */ const upIcon = ({"src":"/_next/static/media/upIcon.7f3a1c96.png","height":123,"width":114,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAARVBMVEX///7+/v7+/f79/f78/P7+/v7+/v79/f7+/v79/f7+/v7+/v7+/v7+/v7+/v7///76+v7y9P7///7+/v79/f7Jzf65xP7sL3EPAAAAEnRSTlMAAAAAAAMQf4CAiYqio7v1+/tuMQbaAAAAPUlEQVR42hXLSRKAIAwAwQmQiIoR4vL/pyrXrmpUbDdRKH57gdzijCNToz89KkuMd8SKTG8CyS9P8L/NRD9FaAIljURkswAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./hook/useViewPort.js
var useViewPort = __webpack_require__(2939);
// EXTERNAL MODULE: ./common/Navbar/navbarStyle.js
var navbarStyle = __webpack_require__(9656);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./common/Footer/Footer.jsx







// import linkdin from "../../public/assets/images/linkdin.png";
// import telegram from "../../public/assets/images/telegram.png";
// import instagram from "../../public/assets/images/instagram.png";

// import whatsapp from "../../public/assets/images/whatsapp.png";








const Footer = ()=>{
    const languageSelector = (0,external_react_redux_.useSelector)((state)=>state.language);
    const { languageData  } = languageSelector;
    const router = (0,router_.useRouter)();
    const { width  } = (0,useViewPort/* default */.Z)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterStyle, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "line"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(WapperIcon, {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: upIcon,
                        alt: "up",
                        layout: "intrinsic",
                        objectFit: "contain"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container d-flex",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Right, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* LogoStyle */.q8, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: logo/* default */.Z,
                                    alt: "logo",
                                    layout: "intrinsic",
                                    objectFit: "contain",
                                    width: 120,
                                    height: 120
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "desc mb-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(GlobalStyle/* WrapperText */.Pk, {
                                    width: "80%",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                        size: "15px",
                                        color: "#000",
                                        children: languageData.desc_goal_about
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Left, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                size: "16px",
                                color: "#053EFF",
                                weight: "bold",
                                children: languageData.contact_subTitle
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(List, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ListItem, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                                size: "13px",
                                                children: languageData.title_phonenumber_footer
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperIcon, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: phone,
                                                        alt: "phone number",
                                                        layout: "fixed",
                                                        width: 30,
                                                        height: 30
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "mx-2",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
                                                            size: "13px",
                                                            en: router.locale === "en" ? "en" : "",
                                                            children: [
                                                                router.locale === "en" && "+",
                                                                "98-9352163631",
                                                                router.locale === "fa" && "+"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ListItem, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                                size: "13px",
                                                children: languageData.address_company
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperIcon, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: images_location,
                                                        alt: "phone number",
                                                        layout: "fixed"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "mx-2",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                                            size: "13px",
                                                            children: languageData.address_company_desc
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ListItem, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                                size: "13px",
                                                children: languageData.title_email_footer
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperIcon, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: email,
                                                        alt: "phone number",
                                                        layout: "fixed"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "mx-2",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                                                            size: "13px",
                                                            children: "info@metanext.biz"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SubFooter, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Typography/* default */.Z, {
                        size: "13px",
                        weight: "400",
                        children: languageData.alert_message
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Footer_Footer = (Footer); // "start": "NODE_ENV=production node server.js",


/***/ }),

/***/ 8734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navbar_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/HeaderTitle/HeaderTitle.jsx
var HeaderTitle = __webpack_require__(5658);
// EXTERNAL MODULE: ./common/Navbar/navbarStyle.js
var navbarStyle = __webpack_require__(9656);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./common/Select/Select.jsx


const Select = ({ items , onChange , value  })=>{
    return /*#__PURE__*/ _jsx(SelectStyle, {
        value: value,
        onChange: onChange
    });
};
const SelectStyle = (external_styled_components_default()).select`
  border: none;
  outline: none;
  font-size: 14px;
`;
const Option = (external_styled_components_default()).option`
  width: 50px;
  height: 50px;
  display: flex;
`;
/* harmony default export */ const Select_Select = ((/* unused pure expression or super */ null && (Select)));

// EXTERNAL MODULE: ./common/Button/Button.jsx
var Button = __webpack_require__(7252);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./hook/useViewPort.js
var useViewPort = __webpack_require__(2939);
;// CONCATENATED MODULE: ./public/assets/images/timebar.png
/* harmony default export */ const timebar = ({"src":"/_next/static/media/timebar.9c99d4d4.png","height":14,"width":19,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAh0lEQVR42mNgsfvXwmL77z8Qf2EF0kD+PAYgALJZgGKMDKw2/wSAWJ3F5p8qEGuC+AzIAKgjE4hvs9r9uwikLwHpa0DdN4Hs+0ATNjIACS0gjgUKRgNxFFAiEagoF0jnA8VDGICEA5DTCMQVUPe4MiADoEAaUOcxIN4BxMeBuAJqNRuL7T9mADTpRMFm9S4aAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/images/close.png
/* harmony default export */ const images_close = ({"src":"/_next/static/media/close.b267bef6.png","height":14,"width":14,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAXklEQVR42iWNMQ7AIAwDM/QPcdoRNpjg60isUV5WBzZbPtuChSGCxx6Rd9gSTGw0EdpmWycFOkLLVyy0pyWqFW6u9bjsMnU4yo2zG2QqgltnebN7tzYfbelMlHA+rh9pVhRx1Nrv5gAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./public/assets/images/logo.png
var logo = __webpack_require__(873);
;// CONCATENATED MODULE: ./public/assets/images/iran.png
/* harmony default export */ const iran = ({"src":"/_next/static/media/iran.f3109c4b.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnUlEQVR42oXPvQ7BYBhH8fO8LRI2YjY2drN7cH0Gg7gYq7gBJiFEStu078efO+hZzvyjL8u3q1143Rc8rp4WwwMZwjGAycXWh42Q8FVNCjAKjqp8E9qWGN/Y1zcBAzPH83SkDh/mRYFiQqkjn7QJJMgMa4Y0fsi4AyVhNsLOy0IAOIdNZ//lNM8bZQxIwvawEywAD5iADBRhILj0Mn+6zEvZ8nrQwwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/images/iraq.png
/* harmony default export */ const iraq = ({"src":"/_next/static/media/iraq.9661ffcf.png","height":68,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAjklEQVR42l2MzQqCQBRGz53RKDRKhHoc8f17iHYtdMAyaGx+btayAx98nMWRC9tRKFslJMWL8EOFg1UWVxR936KKKTe2qGs0Z1gXHncwppXsfQaRkALDNCLGYI3l3JzIOanxQFjlbZ64TgPD68kc3wSBBZC+63SFalfR7I/EFAnxW3MUxgLgAAUyoH/ffQA7WEgmyfwJwgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/images/kingdom.png
/* harmony default export */ const kingdom = ({"src":"/_next/static/media/kingdom.af95e53a.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAxElEQVR42oWPS2rCUBhGf0p33UEnNa2JGRSpmse9ShWfF8EkgiAOJD5WYDK6YLbhF/jUFXg2cM6Rl9wOJ3+htlrkL7Kuiq0/iOU9iJZNo7HPW+J8GF5We47mZ9pgTtubcax3vGQHfjXXlNLto/I1uEpQt7uoHQ9MU1x7E5SNCFI6ClU4A9MM9bcHtDtgkqD6/UfhDiANd80iyzlSO9rulDZccDg5snhonc8l5RlifoyStyC0rX5sPR2LdEITbDTyo/fy8g5QIYhgWLAeEAAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./helper/smoothScroll.js
function handleScroll(data, viewMode) {
    const el = document.getElementById(data);
    el?.scrollIntoView({
        behavior: "smooth",
        block: viewMode
    });
}

;// CONCATENATED MODULE: external "react-bootstrap/Dropdown"
const Dropdown_namespaceObject = require("react-bootstrap/Dropdown");
var Dropdown_default = /*#__PURE__*/__webpack_require__.n(Dropdown_namespaceObject);
;// CONCATENATED MODULE: ./common/Navbar/Navbar.jsx



















const Navbar = ()=>{
    const { 0: showSidebar , 1: setShowSidebar  } = (0,external_react_.useState)(true);
    const { 0: flag , 1: setFlag  } = (0,external_react_.useState)(iran);
    const languages = [
        {
            id: "1",
            label: "\u0627\u06CC\u0631\u0627\u0646",
            value: "fa"
        },
        {
            id: "2",
            label: "\u0627\u0646\u06AF\u0644\u06CC\u0633\u06CC",
            value: "en"
        },
        {
            id: "3",
            label: "\u0639\u0631\u0628\u06CC",
            value: "ar"
        }, 
    ];
    const router = (0,router_.useRouter)();
    const type = router.locale;
    const { width  } = (0,useViewPort/* default */.Z)();
    const onChange = (event)=>{
        const lng = event.target.value;
        router.push("/", "/", {
            locale: lng
        });
    };
    const languageSelector = (0,external_react_redux_.useSelector)((state)=>state.language);
    const { languageData  } = languageSelector;
    const navigateToHomePage = (route)=>{
        router.push("/", "/", {
            locale: route
        });
        setShowSidebar(true);
        if (route === "fa") {
            setFlag(iran);
        } else if (route === "en") {
            setFlag(kingdom);
        } else if (route === "ar") {
            setFlag(iraq);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* StyleNav */.mO, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* Nav */.JL, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* LogoStyle */.q8, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: logo/* default */.Z,
                                    alt: "logo",
                                    layout: "fixed",
                                    objectFit: "contain",
                                    width: 120,
                                    height: 120
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* WrapperLogo */.u0, {
                        showSidebar: showSidebar,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* MenuList */.qy, {
                                children: [
                                    width <= 1022 && /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* ListItem */.HC, {
                                        onClick: ()=>{
                                            handleScroll("home", "start");
                                            setShowSidebar(true);
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* ResponsiveLogo */.li, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: logo/* default */.Z,
                                                alt: "logo",
                                                layout: "fixed",
                                                objectFit: "contain",
                                                width: 120,
                                                height: 50
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* ListItem */.HC, {
                                        border: type === "en" ? "true" : "",
                                        onClick: ()=>{
                                            handleScroll("about", "start");
                                            setShowSidebar(true);
                                        },
                                        children: [
                                            width <= 1022 ? null : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: timebar,
                                                alt: "timebar",
                                                layout: "fixed",
                                                onClick: ()=>setShowSidebar(!showSidebar)
                                            }),
                                            languageData.menu_item_about ? languageData.menu_item_about : ""
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* ListItem */.HC, {
                                        border: type === "en" ? "true" : "",
                                        onClick: ()=>{
                                            handleScroll("service", "start");
                                            setShowSidebar(true);
                                        },
                                        children: languageData.menu_item_service ? languageData.menu_item_service : ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* ListItem */.HC, {
                                        border: type === "en" ? "true" : "",
                                        onClick: ()=>{
                                            handleScroll("features", "start");
                                            setShowSidebar(true);
                                        },
                                        children: languageData.menu_item_features ? languageData.menu_item_features : ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(navbarStyle/* ListItem */.HC, {
                                        border: type === "en" ? "true" : "",
                                        onClick: ()=>{
                                            handleScroll("comment", "start");
                                            setShowSidebar(true);
                                        },
                                        children: languageData.menu_item_comment ? languageData.menu_item_comment : ""
                                    })
                                ]
                            }),
                            width <= 1022 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* WrapperButton */.CJ, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "language",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dropdown_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Toggle, {
                                                    variant: "success",
                                                    id: "dropdown-basic",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: flag,
                                                        alt: "kingdom",
                                                        layout: "intrinsic",
                                                        objectFit: "contain"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dropdown_default()).Menu, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                            href: "",
                                                            onClick: ()=>navigateToHomePage("fa"),
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: iran,
                                                                alt: "iran",
                                                                layout: "intrinsic"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                            href: "",
                                                            onClick: ()=>navigateToHomePage("ar"),
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: iraq,
                                                                alt: "iraq",
                                                                layout: "intrinsic"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                            href: "",
                                                            onClick: ()=>navigateToHomePage("en"),
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: kingdom,
                                                                alt: "kingdom",
                                                                layout: "intrinsic"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "close",
                                        onClick: ()=>setShowSidebar(!showSidebar),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: images_close,
                                            alt: "close",
                                            layout: "fixed"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* ResponsiveBtn */.wQ, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "mx-1"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "mx-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    size: "13px",
                                                    radius: "true",
                                                    bgColor: "#fff",
                                                    color: "#053EFF",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/login",
                                                        children: languageData.login_label_button ? languageData.login_label_button : ""
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }) : null
                        ]
                    }),
                    width <= 1022 ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: timebar,
                        alt: "timebar",
                        layout: "fixed",
                        onClick: ()=>setShowSidebar(!showSidebar)
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(navbarStyle/* WrapperButton */.CJ, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dropdown_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Toggle, {
                                        variant: "success",
                                        id: "dropdown-basic",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: flag,
                                            alt: "kingdom",
                                            layout: "intrinsic",
                                            objectFit: "contain"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dropdown_default()).Menu, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                href: "",
                                                onClick: ()=>navigateToHomePage("fa"),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: iran,
                                                    alt: "iran",
                                                    layout: "intrinsic"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                href: "",
                                                onClick: ()=>navigateToHomePage("ar"),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: iraq,
                                                    alt: "iraq",
                                                    layout: "intrinsic"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Dropdown_default()).Item, {
                                                href: "",
                                                onClick: ()=>navigateToHomePage("en"),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: kingdom,
                                                    alt: "kingdom",
                                                    layout: "intrinsic"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mx-2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mx-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    radius: "true",
                                    bgColor: "#fff",
                                    color: "#053EFF",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/login",
                                        children: languageData.login_label_button ? languageData.login_label_button : ""
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Navbar_Navbar = (Navbar);


/***/ }),

/***/ 9656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CJ": () => (/* binding */ WrapperButton),
/* harmony export */   "HC": () => (/* binding */ ListItem),
/* harmony export */   "JL": () => (/* binding */ Nav),
/* harmony export */   "li": () => (/* binding */ ResponsiveLogo),
/* harmony export */   "mO": () => (/* binding */ StyleNav),
/* harmony export */   "q8": () => (/* binding */ LogoStyle),
/* harmony export */   "qy": () => (/* binding */ MenuList),
/* harmony export */   "u0": () => (/* binding */ WrapperLogo),
/* harmony export */   "wQ": () => (/* binding */ ResponsiveBtn)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Nav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().nav)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 70px;
  /* overflow: hidden; */
`;
const WrapperLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  justify-content: center;
  align-items: center;

  @media (max-width: 1022px) {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    position: fixed;
    top: 0;
    z-index: 10;
    left: 0;
    background-color: #fff;
    width: 100%;
    padding: 0 2rem;
    height: 100vh;
    transition: 0.4s all ease-in-out;
    transform: ${({ showSidebar  })=>showSidebar ? "translateX(-1025px)" : "translateX(0px)"};
  }
`;
const MenuList = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul)`
  display: flex;
  align-items: center;
  margin: 0;
  list-style: none;
  padding: 0;

  @media (max-width: 1022px) {
    display: flex;
    flex-direction: column;
  }
`;
const ListItem = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().li)`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 1.5rem;
  border-left: 1px dashed ${({ theme  })=>theme.color_primary};
  /* border-right: 1px dashed ${({ theme  })=>theme.color_primary}; */
  cursor: pointer;
  font-size: 15px;
  &:nth-child(4) {
    border: none;
  }

  &:nth-child(1) {
    border-left: ${({ border  })=>border ? "none" : "1px dashed #053EFF"};
  }

  &:nth-child(3) {
    border-right: ${({ border  })=>border ? "1px dashed #053EFF" : "none"};
  }

  a {
    color: #000000;
    font-size: 15px;
  }
  span {
    margin: 0 0.5rem !important;
  }
  @media (max-width: 1022px) {
    margin: 2rem 0;
    border: none;
    &:nth-child(1) {
      border: none;
    }
    &:nth-child(3) {
      border-right: none;
    }
  }
`;
const WrapperButton = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
  @media (max-width: 1022px) {
    display: flex;
    justify-content: center;
  }
  .language {
    position: absolute;
    top: 30px;
    left: 10px;
  }
  .close {
    position: absolute;
    top: 43px;
    right: 27px;
  }
`;
const ResponsiveBtn = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  justify-content: center;
`;
const StyleNav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 100%;
  box-shadow: 0px 7px 25px rgba(5, 62, 255, 0.08);
  position: sticky;
  top: 0;
  background-color: #fff;
  z-index: 100;
  cursor: pointer;
`;
const LogoStyle = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  /* width: 40px;
  height: 40px; */
  display: flex;
`;
const ResponsiveLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  margin-top: 0px;
  /* width: 60px;
  height: 40px; */
`;


/***/ }),

/***/ 2563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9742);
/* harmony import */ var _redux_action_language__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7706);
/* harmony import */ var _styles_GlobalStyle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3369);
/* harmony import */ var _common_Footer_Footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(24);
/* harmony import */ var _common_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8734);
/* harmony import */ var _public_locales_ar_common_json__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9225);
/* harmony import */ var _public_locales_fa_common_json__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1383);
/* harmony import */ var _public_locales_en_common_json__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3172);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














const MainLayout = ({ children  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const language = router.locale;
    const languageData = language === "en" ? _public_locales_en_common_json__WEBPACK_IMPORTED_MODULE_12__ : language === "fa" ? _public_locales_fa_common_json__WEBPACK_IMPORTED_MODULE_11__ : _public_locales_ar_common_json__WEBPACK_IMPORTED_MODULE_10__;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useLayoutEffect)(()=>{
        if (language === "en") {
            document.body.style.direction = "ltr";
            dispatch((0,_redux_action_language__WEBPACK_IMPORTED_MODULE_13__/* .setLanguage */ .m)(languageData));
        } else {
            document.body.style.direction = "rtl";
            dispatch((0,_redux_action_language__WEBPACK_IMPORTED_MODULE_13__/* .setLanguage */ .m)(languageData));
        }
        router.push(`/${language}`);
    }, [
        language,
        dispatch,
        languageData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, {
                theme: _styles_theme__WEBPACK_IMPORTED_MODULE_6__/* .palletColor */ .Z,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_GlobalStyle__WEBPACK_IMPORTED_MODULE_7__/* .GlobalStyle */ .ZL, {}),
                    router.pathname === "/login" || router.pathname === "/contact" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                    children,
                    router.pathname === "/login" || router.pathname === "/contact" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Footer_Footer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _redux_store_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9454);
/* harmony import */ var _layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2563);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__]);
_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
        store: _redux_store_store__WEBPACK_IMPORTED_MODULE_2__/* .store */ .h,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7706:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ setLanguage)
/* harmony export */ });
const setLanguage = (languageData)=>(dispatch)=>{
        if (languageData) {
            dispatch({
                type: "GET_LANGUAGE_MODE",
                payload: languageData
            });
        }
    };


/***/ }),

/***/ 9454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* binding */ store)
});

// UNUSED EXPORTS: wrapper

;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "redux-devtools-extension"
const external_redux_devtools_extension_namespaceObject = require("redux-devtools-extension");
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
;// CONCATENATED MODULE: ./redux/reducer/language.js
const languageReducer = (state = {
    languageData: {}
}, action)=>{
    switch(action.type){
        case "GET_LANGUAGE_MODE":
            return {
                ...state,
                languageData: action.payload
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./redux/reducer/index.js


const reducers = (0,external_redux_namespaceObject.combineReducers)({
    language: languageReducer
});

;// CONCATENATED MODULE: ./redux/store/store.js





// initial states here
const initalState = {};
// middleware
const middleware = [
    (external_redux_thunk_default())
];
const store = (0,external_redux_namespaceObject.createStore)(reducers, initalState, (0,external_redux_devtools_extension_namespaceObject.composeWithDevTools)((0,external_redux_namespaceObject.applyMiddleware)(...middleware)));
// assigning store to next wrapper
const makeStore = ()=>store;
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore);


/***/ }),

/***/ 9742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ palletColor)
/* harmony export */ });
const palletColor = {
    color_primary: "#053EFF",
    color_gray: "#6F6F6F"
};


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 9225:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"login_title":"تسجيل الدخول في متانکست","login_label_phonenumber":"رقم الهاتف","login_label_password":"كلمه السر","login_label_button":"ورود","login_label":"ورود","singup_label_button":"التسجيل","menu_item_home":"الصفحة الرئيسية","menu_item_auth":"اشترك تسجيل الدخول","menu_item_about":"معلومات عنا","menu_item_contact":"طلب استشارة","menu_item_features":"صفات","menu_item_comment":"معرفی","menu_item_service":"خدمات","main_title":"مقدمة من شركة - متانکست","main_desc":"شركة Metanx Store نظرة إلى المستقبل","title_header":"سافر إلى المستقبل معنا!","desc_header":"MetaNext هو نظام إدارة الأعمال المتكاملة الأكثر شمولاً الذي تم إنشاؤه لأول مرة في إيران لغرض إدارة الأعمال الكلية المتكاملة. يتضمن هذا النظام: المتجر الإلكتروني ، ونظام المحاسبة ، وإدارة العملاء ، وتصميم المواقع والتطبيقات ، وإدارة الموارد البشرية.","button_header":"ورود به پنل","title_about":"حول ميتا نيكست","subTitle_about":"كن دائما متقدما بخطوة على الآخرين","title_goal_about":"استهداف","desc_goal_about":"تهدف MetaNext إلى دمج العمليات والأنظمة والخدمات الإلكترونية المتعلقة بالأعمال. نظرًا لأن تشتت البرامج المستخدمة في الأعمال يتسبب في تخلف وبطء في النشاط ، فإن Meta Next من خلال دمج جميع العمليات ، بالإضافة إلى تحسين السرعة والأداء ، يؤدي إلى التطوير السريع والإدارة المتكاملة للشركات الصغيرة والمتوسطة والكبيرة. يصبح.","title_mention_about":"بعثة","desc_mention_about":"تتمثل مهمة Meta Next في تسريع تطوير الأعمال وتسريع نمو أي نشاط تجاري في أي مكان وزمان. لهذا الغرض ، فإن Meta Next ، من خلال تقديم نظامها المتكامل ، تخلق أرضية للنمو السريع وتطوير الأعمال.","title_profecy_about":"نبوءة","desc_profecy_about":"تتمثل مهمة MetaNext كمجموعة من المعرفة في التحرك مع موجة العلم والتكنولوجيا والتحرك نحو مستقبل مشرق ، وتسريع نمو وتطوير الأعمال من خلال مركزية وتكامل مهمة MetaNext النهائية.","title_viewport_about":"نظرة مستقبلية","desc_viewport_about":"بالنظر إلى المستقبل ، يتجه Meta Next نحو آفاق مشرقة. تتمثل الرؤية المستقبلية لـ Meta Next في السعي دائمًا لتطوير وتحديث بنيتها التحتية من أجل أن تكون دائمًا متقدمًا على منافسيها.","title_service":"تقديم أقسام مختلفة من Meta Next","title_crm_service":"CRM","desc_crm_service":"يتضمن نظام CRM أو إدارة علاقات العملاء أتمتة المبيعات والتسويق ودعم العملاء وتتبع خدمة العملاء. يعد CRM Metanxt أحد أفضل أنظمة إدارة علاقات العملاء وهو جزء مهم من نظام MetaNext.","title_account_service":"نظام المحاسبة","desc_account_service":"تعد المحاسبة جزءًا مهمًا من أي عمل تجاري اليوم ، سواء كانت الأعمال الصغيرة أو الكبيرة تحتاج جميعها إلى المحاسبة. يعد نظام محاسبة Meta Next في خدمتك كجزء من نظام Meta Next لتلبية الاحتياجات المتعلقة بمحاسبة الأعمال.","title_shop_service":"متجر على الانترنت","desc_shop_service":"يعد امتلاك متجر على الإنترنت أحد أهم متطلبات أي عمل تجاري ، فإن نظام Meta Next ، من خلال وجود منصات مناسبة لمتجر عبر الإنترنت ، قد وفر الأساس لإنشاء متجر على الإنترنت.","title_mangeContent_service":"إدارة إنتاج المحتوى","desc_manageContent_service":"المتاجر المتخصصة لديها عملاء متخصصون ، ويحتاج العملاء المتخصصون إلى موجز الأخبار المتعلقة بأعمالهم. يوفر نظام MetaNext منصة جيدة للشركات لنشر المحتوى المرغوب فيه.","title_all_services":"لوحة إدارة متكاملة","desc_all_services":"باستخدام لوحة الإدارة المتكاملة ، يمكنك إدارة جميع الأنظمة المتعلقة بعملك في أي وقت وفي أي مكان","title_pannel_management":"لوحة الادارة","desc_pannel_management":"باستخدام لوحة إدارة MetaNext ، سيكون لديك جميع الأنظمة اللازمة للإدارة المتكاملة لأي عمل. تتضمن لوحة الإدارة المتكاملة MetaNext أربعة أقسام: CRM ، ونظام المحاسبة ، والمتجر عبر الإنترنت ، وإنتاج المحتوى.","service_one_pannel":"سلامة النظام","service_one_pannel_desc":"تقدم Meta Next كل ما تحتاجه لإدارة عملك في نظام متكامل واحد.","service_two_pannel":"استشارة مجانية","service_two_pannel_desc":"فريق MetaNext الاستشاري مستعد لتقديم خدمات استشارية مجانية لتنمية أعمالك.","service_three_pannel_desc":"فريق MetaNext الاستشاري مستعد لتقديم خدمات استشارية مجانية لتنمية أعمالك.","service_four_pannel":"التسويق عبر الإنترنت","service_four_pannel_desc":"يوفر MetaNext الأساس لتطوير عملك.","service_five_pannel":"التسويق عبر الإنترنت","service_five_pannel_desc":"جرب جميع أنواع التسويق عبر الإنترنت مع MetaNext.","service_six_pannel":"دعم على مدار 24 ساعة","service_six_pannel_desc":"نحن بجانبك 24 ساعة في اليوم ومستعدون لخدمتك.","comment_people_title":"گواهی","comment_people_subTitle":"ماذا يقول الناس؟","comment_person_1":"MetaNext هو نظام إدارة الأعمال المتكاملة الأكثر شمولاً الذي تم إنشاؤه لأول مرة في إيران لغرض إدارة الأعمال الكلية المتكاملة. يتضمن هذا النظام: المتجر الإلكتروني ، ونظام المحاسبة ، وإدارة العملاء ،","comment_person_name_1":"مهدي الغفاري","comment_person_job_1":"مبرمج أمامي","comment_person_desc_2":"Metanext هو نظام إدارة الأعمال الأكثر شمولاً الذي تم إنشاؤه لأول مرة في إيران للإدارة المتكاملة للشركات الكبيرة. يتضمن هذا النظام: تخزين","comment_person_name_2":"محمود انصاری","comment_person_job_2":"مبرمج أمامي","comment_person_name_3":"حمید واعظی","comment_person_job_3":"اصنع مبرمج","comment_person_name_4":"علیرضا رحیمی","comment_person_job_4":"مبرمج أمامي","support_title":"Methanext هو ركيزة للنمو. طور عملك","support_subTitle":"مهمتنا هي دعم أي إجراء لدمج الأنظمة المتعلقة بالأعمال!","support_desc":"نحن ندعم الشركات الصغيرة والمتوسطة والكبيرة لتحقيق تطوير وتكامل أنظمتها.","title_phonenumber_footer":"رقم الهاتف","title_email_footer":"عنوان البريد الالكترونى","address_company":"عنوان الشركة","address_company_desc":"ایران، خراسان رضوی، مشهدالمقدس","happy_client":"عدد سطور الكود","project_done":"عدد ساعات العمل","win_awar":"عدد الأشخاص","change_login_mode":"إذا كان لديك حساب ، قم بتسجيل الدخول إلى حسابك","coontact_title":"طلب استشارة","contact_fullName":"الاسم الكامل","contact_phoneNumber":"رقم الهاتف","contact_subject":"رسالة الموضوع","contact_desc":"وصف","contact_button":"ارسال","contact_button_back":"العودة","contact_subTitle":"معلومات التواصل","contact_subTitle_desc":"املأ النموذج وسيتصل بك فريقنا في غضون الـ 24 ساعة القادمة","title_security":"أمن المعلومات","subTitle_security":"حماية المعلومات الخاصة بك ضد الهجمات","desc_serurity":"يقوم نظام Metanx دائمًا بتخزين معلوماتك على خادمه المخصص ولا يمكن لأي جهاز أو مؤسسة الوصول إليها.","title_smart_security":"الذكاء في تخزين المعلومات","desc_smart_security":"ينشئ نظام Metantext مفتاحًا فريدًا للذكاء ويكون لكل عميل فقط حق الوصول إلى معلوماته ولا يمكن لأي مستخدم آخر الوصول إلى معلوماتك.","title_encrypt_security":"تشفير المعلومات","desc_encrypt_security":"يتم تخزين معلومات المستخدم الخاصة بك بشكل مشفر بالكامل على خوادمنا","title_backup_security":"النسخ الاحتياطي للمعلومات","desc_backup_security":"سيتم نسخ بياناتك احتياطيًا تلقائيًا كل 24 ساعة ، ويمكنك أيضًا نسخها احتياطيًا.","title_xander_security":"مقاومة لهجمات SQLEngection و Xss","desc_xander_security":"سيكون نظام Methanext مقاومًا لهجمات SQLEngection و Xss وسيختبر دائمًا خوادمه المخصصة ضد الهجمات المختلفة.","question_contact":"ماذا تفضل؟","question_contact_one":"لنتحدث على الهاتف","question_contact_two":"دعنا نتحادث على WhatsApp","confirm_request":"طلب التسجيل","title_provider":"لوحة المورد","desc_provider":"لأول مرة ، أنشأ نظام Metanext لوحة متكاملة للموردين ، يمكن للموردين من خلالها إدارة أعمالهم بطريقة متكاملة. تتضمن لوحة الموردين الوصول إلى أجزاء مختلفة من نظام Metanext ، بما في ذلك تحميل المنتج والمحاسبة وتتبع العملاء.","free_watch_video":"تعلم مجانا","alert_message":"جميع الحقوق محفوظة لموقع Metext وأي نسخ غير مسموح به وسيتم مقاضاته","success_message":"سجلت بنجاح","header_login":"تسجيل الدخول إلى Metatext","contact_metanext":"اطلب النصيحة من Metantext","intro_title":"السيد قاسم نوري مؤسس ومدير مشروع Metankest","intro_desc":"إدارة عملك على الإنترنت في أي وقت وفي أي مكان باستخدام Metext. نحن هنا لمرافقتك على طريق التقدم والنجاح. الهدف من Metext هو دمج الأنظمة المطلوبة لأي عمل تجاري. يتطلب النشاط الاقتصادي في الفضاء عبر الإنترنت تزويدك بأدوات ويب حديثة وعملية. Metext هو رفيقك وشريكك بهذه الطريقة حتى تتمكن من إدارة عملك عبر الإنترنت.","intro_footer":"سافر إلى المستقبل معنا!"}');

/***/ }),

/***/ 3172:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"login_title":"Login Meta Next","login_label_phonenumber":"phone number","login_label_password":"password","login_label_button":"Login or Signup","login_label":"Login","singup_label_button":"Sing up","menu_item_home":"main page","menu_item_auth":"sign up/ log in","menu_item_about":"About us","menu_item_contact":"Consultation Request","menu_item_features":"Features","menu_item_service":"Services","menu_item_comment":"Introduction","main_title":"introduction of a company - metanext","main_desc":"Metanx Store Company A Look To The Future","title_header":"Travel to the future with us!","desc_header":"MetaNext is the most comprehensive integrated business management system that was built for the first time in Iran for the purpose of integrated macro business management. This system includes: online store, accounting system, customer management, website and application design and human resource management.","button_header":"ورود به پنل","title_about":"About Meta Next","subTitle_about":"Always be one step ahead of others","title_goal_about":"Target","desc_goal_about":"MetaNext aims to integrate business-related electronic processes, systems and services. Because the dispersion of software used in businesses causes backwardness and slowness of activity, Meta Next by integrating all processes, in addition to speed and performance improvement, leads to rapid development and integrated management of small, medium and large businesses. Becomes.","title_mention_about":"Mission","desc_mention_about":"MetaNext\'s mission is to accelerate business development and accelerate the growth of any business in any place and time. For this purpose, Meta Next, by providing its integrated online system, creates the ground for rapid growth and development of businesses.","title_profecy_about":"Prophecy","desc_profecy_about":"The mission of MetaNext as a collection of knowledge is to move with the wave of science and technology and move towards a bright future, accelerating the growth and development of businesses through the centralization and integration of the ultimate mission of MetaNext.","title_viewport_about":"Future outlook","desc_viewport_about":"Looking to the future, Meta Next is moving towards bright horizons. The future vision of Meta Next is to always strive to develop and update its infrastructure in order to always be one step ahead of its competitors.","title_service":"Introducing different sections of Meta Next","title_crm_service":"CRM","desc_crm_service":"CRM or customer relationship management system includes sales automation, marketing, customer support and customer service tracking. CRM Metantext is one of the best online customer relationship management systems and is an important part of the MetaNext system.","title_account_service":"accounting system","desc_account_service":"Accounting is an important part of any business today, whether small or large businesses all need accounting. Meta Next online accounting system is at your service as one of the parts of Meta Next system in order to meet the needs related to business accounting.","title_shop_service":"Online Store","desc_shop_service":"Having an online store is one of the most important requirements of any business, Meta Next system, by having suitable platforms for an online store, has provided the ground for creating an online store and online business.","title_mangeContent_service":"Content Production ","desc_manageContent_service":"Specialty stores have specialized customers, and specialized customers need news feeds related to their business. MetaNext system provides a good platform for businesses to publish desirable content.","title_all_services":"Integrated management panel","desc_all_services":"With the integrated management panel, you can manage all the systems related to your business anytime, anywhere.","title_pannel_management":"Admin Panel","desc_pannel_management":"With the MetaNext admin panel, you will have all the systems needed for the integrated management of any business. MetaNext integrated management panel includes four sections: CRM, accounting system, online store and content production.","service_one_pannel":"System integrity","service_one_pannel_desc":"Meta Next brings everything you need to manage your business in one integrated system.","service_two_pannel":"free consultation","service_two_pannel_desc":"MetaNext Consulting Team is ready to provide free consulting services to grow your business.","service_three_pannel":"Development of platforms","service_three_pannel_desc":"MetaNext provides the basis for the development of your business.","service_four_pannel":"Online marketing","service_four_pannel_desc":"Experience all kinds of online marketing with MetaNext.","service_five_pannel":"24-hour support","service_five_pannel_desc":"We are by your side 24 hours a day and are ready to serve you.","service_six_pannel":"Manage Source People","service_six_pannel_desc":"With MetaNext, manage the human resources, which is the most valuable asset of any organization, in the best possible way.","comment_people_title":"Certificate","comment_people_subTitle":"What do people say?","comment_person_1":"MetaNext is the most comprehensive integrated business management system that was built for the first time in Iran for the purpose of integrated macro business management. This system includes: online store, accounting system, customer","comment_person_name_1":"Mehdi Ghaffari","comment_person_job_1":"Front Developer","comment_person_desc_2":"Metanext is the most comprehensive integrated business management system that was built for the first time in Iran for the integrated management of large businesses. This system includes: store","comment_person_name_2":"Mahmoud Ansari","comment_person_job_2":"Front Developer","comment_person_name_3":"Hamid Vaezei","comment_person_job_3":"Backend Developer","comment_person_name_4":"Alireza Rahimi","comment_person_job_4":"Front Developer","support_title":"Methanext is a substrate for growth. Develop your business","support_subTitle":"Our job is to support any action to integrate business-related systems!","support_desc":"We support small, medium and large businesses to achieve the development and integration of their systems.","title_phonenumber_footer":"Phone Number","title_email_footer":"Email Address","address_company":"Company Address","address_company_desc":"Iran, Khorasan Razavi, Mashhad","happy_client":"Number of lines of code","project_done":"Number of hours worked","win_awar":"Number of persons","change_login_mode":"If you have an account, log in to your account","coontact_title":"Consultation Request","contact_fullName":"Full Name","contact_phoneNumber":"Phone Number","contact_subject":"Subject Message","contact_desc":"Description","contact_button":"Send","contact_button_back":"Back","contact_subTitle":"Contact Information","contact_subTitle_desc":"Fill out the form and our team will contact you within the next 24 hours","title_security":"Information security","subTitle_security":"Protect your information against attacks","desc_serurity":"Metanx system always stores your information on its dedicated server and no organ or institution has access to it.","title_smart_security":"Intelligence in information storage","desc_smart_security":"The Metantext system creates a unique key for intelligence and only each customer has access to their information and no other user has access to your information.","title_encrypt_security":"Information encryption","desc_encrypt_security":"Your user information is stored completely encrypted on our servers","title_backup_security":"Backup of information","desc_backup_security":"Your data will be backed up automatically every 24 hours, and you can also back it up.","title_xander_security":"Resistant to SQLEngection and Xss attacks","desc_xander_security":"Methanext system will be resistant to SQLEngection and Xss attacks and will always test its dedicated servers against different attacks.","question_contact":"What do you prefer?","question_contact_one":"Speaking with phone","question_contact_two":"Chatting in whatsapp","confirm_request":"Confirm Request","title_provider":"Provider Pannle","desc_provider":"For the first time, the Metanext system has created an integrated panel for suppliers, through which suppliers can manage their business in an integrated manner. The supplier panel includes access to various parts of the Metanext system, including product loading, accounting and customer tracking.","free_watch_video":"Learn for free","alert_message":"All rights are reserved for Metext website and any copying is not allowed and will be prosecuted","success_message":"Successfully Done.","header_login":"Login To Metanext","contact_metanext":"Ask for advice from Metantext","intro_title":"Mr. Qasem Noori, the founder and manager of Metanext project","intro_desc":"Manage your business online anytime and anywhere with Metext. We are here to accompany you on the path of progress and success. The goal of Metext is to integrate the systems required for any business.","intro_desc2":"Economic activity in the online space requires equipping you with modern and practical tools on the web, Metext is your companion and synchronist in this way so that you can manage your businesses in the online space.","intro_footer":"Travel to the future with us!"}');

/***/ }),

/***/ 1383:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"login_title":"ثبت نام در متانکست","login_label_phonenumber":"شماره تماس","login_label_password":"رمز عبور","login_label_button":"ورود یا ثبت نام","singup_label_button":"ثبت نام","login_label":"ورود","menu_item_home":"صفحه اصلی","menu_item_auth":"ثبت نام/ ورود","menu_item_about":"درباره ما","menu_item_contact":"درخواست مشاوره","menu_item_features":"ویژگی ها","menu_item_service":"خدمات ما","menu_item_comment":"معرفی","main_title":"معرفی شرکت - متانکست","main_desc":"شرکت فروشگاهی متانکست نگاهی به آینده","title_header":"با ما به آینده سفر کنید","desc_header":"متا نکست، جامع ترین سیستم یکپارچه مدیریت کسب و کار آنلاین می باشد که برای اولین بار در ایران و به منظور مدیریت یکپارچه کسب و کارهای کلان آنلاین ساخته شده است.","button_header":"ورود به پنل","title_about":"درباره متا نکست","subTitle_about":"همیشه یک گام جلوتر از دیگران باشید.","title_goal_about":"هدف","desc_goal_about":"هدف متا نکست یکپارچه سازی فرایندها، سیستم ها و سرویسهای الکترونیکی مرتبط با کسب و کار می باشد. از آنجا که پراکندگی نرم افزارهای مورد استفاده در کسب و کارها باعث عقب افتادگی و کندی فعالیت می شود، سامانه آنلاین متا نکست با یکپارچه سازی تمامی فرایندها، علاوه بر سرعت و بهبود کارکرد، باعث توسعه سریع و مدیریت یکپارچه کسب و کارهای خرد، متوسط و کلان می شود.","title_mention_about":"ماموریت","desc_mention_about":"ماموریت متا نکست اینست که توسعه کسب و کارها را سرعت بخشد و زمینه تسریع رشد هر کسب و کاری را در هر مکان و زمانی فراهم آورد. برای این منظور متا نکست با ارایه سامانه آنلاین و یکپارچه خود، زمینه رشد و توسعه سریع کسب و کارها را ایجاد می کند.","title_profecy_about":"رسالت","desc_profecy_about":"رسالت متا نکست بعنوان یک مجموعه دانش بنیان اینست که همراه موج علم و فناوری در حرکت باشد و بسوی آینده ای درخشان گام بردارد، تسریع رشد و توسعه کسب و کارها از مسیر متمرکز شدن و یکپارچگی رسالت غایی متا نکست می باشد.","title_viewport_about":"چشم انداز ","desc_viewport_about":"متا نکست با نگاهی به آینده، بسوی افقهای روشن در حرکت است، چشم اندازه آینده متا نکست اینست که همواره در مسیر توسعه و روزآمد شدن زیرساختهای خود تلاش کند تا همیشه یک قدم جلوتر از رقبای خود بایستد. ","title_service":"معرفی بخشهای مختلف متا نکست","title_crm_service":"بخش CRM متانکست","desc_crm_service":"سی آر ام یا سیستم مدیریت ارتباط با مشتری شامل خودکار سازی فروش، بازاریابی، پشتیبانی از مشتری و پیگیری خدمات به مشتریان است. سی آر ام متانکست یکی از بهترین سیستم های مدیریت ارتباط با مشتریان به صورت آنلاین است و یکی از بخشهای مهم سامانه متا نکست می باشد.","title_account_service":"سیستم حسابداری ","desc_account_service":"امروزه حسابداری بخش مهمی از هر کسب و کاری می باشد، چه کسب و کارهای کوچک و چه کسب و کارهای کلان، همگی به حسابداری نیازمند هستند. سیستم حسابداری آنلاین متا نکست در جهت رفع نیازهای مرتبط با حسابداری کسب و کارها بعنوان یکی از بخشهای سامانه متا نکست در خدمت شما می باشد.","title_shop_service":"فروشگاه اینترنتی","desc_shop_service":"داشتن فروشگاه اینترنتی یکی از مهمترین لازمه های هر کسب و کاری است، سامانه متا نکست با داشتن بسترهای مناسب برای یک فروشگاه اینترنتی، زمینه ایجاد فروشگاه اینترنتی و کسب و کار آنلاین را فراهم کرده است.","title_mangeContent_service":"سامانه چت آنلاین و تیکت","title_all_services":"پنل مدیریت یکپارچه","desc_all_services":"با پنل مدیریت یکپارچه میتوانید تمامی سیسیتم های مرتبط با کسب و کارتان را در هر ساعت و هرجا مدیریت کنید","desc_manageContent_service":"سامانه چت آنلاین متانکست این امکان را به شما میدهد که بصورت لحظه ای پاسخگوی نیازمندی ها و مشکلات مشتریانتان باشید.","title_pannel_management":"پنل مدیریت","desc_pannel_management":"با داشتن پنل مدیریت متا نکست، تمام سیستم های مورد نیاز برای مدیریت یکپارچه هر کسب و کاری را در اختیار خواهید داشت. پنل مدیریت یکپارچه متا نکست شامل بخشهای چهارگانه سی آر ام، سیستم حسابداری، فروشگاه اینترنتی و تولید محتوا می باشد.","service_one_pannel":"یکپارچگی سیستم","service_one_pannel_desc":"متا نکست تمام آنچه برای مدیریت کسب و کار نیاز دارید را در یک سیستم یکپارچه به ارمغان می‌آورد.","service_two_pannel":"مشاوره رایگان","service_two_pannel_desc":"تیم مشاوره متا نکست، آماده ارائه خدمات مشاوره‌ای رایگان برای توسعه کسب و کار شماست.","service_three_pannel":"توسعه پلتفرمها","service_three_pannel_desc":"متا نکست زمینه توسعه کسب و کار شما را فراهم می‌کند. ","service_four_pannel":"بازاریابی آنلاین","service_four_pannel_desc":"با متا نکست، انواع بازاریابی آنلاین را تجربه کنید.","service_five_pannel":"پشتیبانی 24 ساعته","service_five_pannel_desc":"در ۲۴ ساعت شبانه‌روز کنار شما و آماده خدمات رسانی به شما هستیم.","service_six_pannel":"مدیریت منابع انسانی","service_six_pannel_desc":"با متا نکست، به بهترین شکل ممکن منابع انسانی که ارزشمندترین دارایی هر سازمان است را مدیریت کنید.","comment_people_title":"نظرات","comment_people_subTitle":"مردم چه می گویند","comment_person_1":"متا نکست، جامع ترین سیستم یکپارچه مدیریت کسب و کار می باشد که برای اولین بار در ایران و به منظور مدیریت یکپارچه کسب و کارهای کلان ساخته شده است. این سامانه شامل: فروشگاه آنلاین","comment_person_name_1":"مهدی غفاری","comment_person_job_1":"توسعه دهنده وب","comment_person_name_2":"محمود انصاری","comment_person_desc_2":"متا نکست، جامع ترین سیستم یکپارچه مدیریت کسب و کار می باشد که برای اولین بار در ایران و به منظور مدیریت یکپارچه کسب و کارهای کلان ساخته شده است. این سامانه شامل: فروشگاه ","comment_person_job_2":"توسعه دهنده وب","comment_person_name_3":"حمید واعظی","comment_person_job_3":"توسعه دهنده سرور","comment_person_name_4":"علیرضا رحیمی","comment_person_job_4":"توسعه دهنده وب","support_title":"متانکست بستری برای رشد توسعه کسب و کار شما","support_subTitle":"کار ما حمایت از هرگونه اقدام در راستای یکپارچه سازی سیستم‌های مرتبط با کسب و کار است!","support_desc":"ما از کسب و کارهای خرد، متوسط و کلان برای رسیدن به توسعه و یکپارچه سازی سیستم‌هایشان حمایت می‌کنیم.","title_phonenumber_footer":"شماره تماس","title_email_footer":"آدرس ایمیل","address_company":"آدرس شرکت","address_company_desc":"ایران، خراسان رضوی، مشهد ","happy_client":"تعداد خط کد","project_done":"تعداد ساعت های کار شده","win_awar":"تعداد افراد","change_login_mode":"در صورت داشتن اکانت به اکانت خود وارد شوید","coontact_title":"درخواست مشاوره","contact_fullName":"نام و نام خانوادگی","contact_phoneNumber":"شماره تماس","contact_subject":"عنوان پیام","contact_desc":"توضیحات","contact_button":"ارسال","contact_button_back":"بازگشت","contact_subTitle":"راه های ارتباطی با ما","contact_subTitle_desc":"فرم مربوطه را پر کنید و تیم ما تا 24 ساعت آینده با شما تماس خواهند گرفت","title_security":"امنیت اطلاعات","subTitle_security":"حفظ و نگهداری اطلاعات شما در برابر حملات","desc_serurity":"سامانه متانکست همواره اطلاعات شما را در سرور اختصاصی خود ذخیره کرده و هیچ ارگان و نهادی به آن دسترسی ندارد","title_smart_security":"هوشمندسازی در نگهداری اطلاعات","desc_smart_security":"سامانه متانکست برای هوشمندسازی یک کلید یکتا می سازد و فقط هر مشتری به اطلاعات خود دسترسی دارد و هیچ کاربر دیگری به اطلاعات شما دسترسی ندارد.","title_encrypt_security":"رمزنگاری اطلاعات","desc_encrypt_security":"اطلاعات کاربری شما کاملا بصورت رمزنگاری شده روی سرورهای ما ذخیره می شود","title_backup_security":"بک آپ از اطلاعات","desc_backup_security":"از اطلاعات شما هر 24 ساعت یکبار به صورت خودکار بک آپ گرفته می شود، همچنین امکان گرفتن نسخه پشتیبان توسط شما نیز هست","title_xander_security":"مقاوم دربرابر حملات SQLEngection و Xss","desc_xander_security":"سامانه متانکست دربرابر حملات SQLEngection و Xss مقاوم خواهد بود و همواره سرورهای اختصاصی خود را در برابر حملات متفاوت تست خواهد کرد","question_contact":"شما چی ترجیح می دهید؟","question_contact_one":"تلفنی باهم صحبت کنیم","question_contact_two":"در واتس اب باهم چت کنیم","confirm_request":"ثبت درخواست","title_provider":"پنل تأمین کننده","desc_provider":"سامانه متا نکست برای اولین بار پنل یکپارچه ای برای تامین کنندگان ایجاد کرده است که تامین کنندگان می توانند از طریق این پنل بصورت یکپارچه کسب و کار خود را مدیریت کنند. پنل تامین کنندگان شامل دسترسی هایی به بخشهای مختلف سامانه متا نکست منجمله بارگزاری محصولات، حسابداری و پیگیری مشتریان می باشد.","free_watch_video":"رایگان آموزش ببینید","alert_message":"کلیه حقوق برای سایت متانکست محفوظ است و هر گونه کپی برداری غیر مجاز بوده و پیگرد قانونی دارد","success_message":"با موفقیت ثبت شد","header_login":"ورود به متانکست","contact_metanext":"درخواست مشاوره از متانکست","intro_title":"آقای قاسم نوری بنیان گذار و مدیر پروژه متانکست","intro_desc":"با متانکست همیشه و همه جا کسب و کارتان را بصورت آنلاین مدیریت کنید. ما اینجاییم تا شما را در مسیر پیشرفت و موفقیت همراهی کنیم، هدف متانکست یکپارچه سازی سیستم های مورد نیاز برای هر کسب و کاری است.","intro_desc2":" فعالیت اقتصادی در فضای آنلاین، مستلزم تجهیز شما به ابزارهای مدرن و کاربردی تحت وب می باشد، متانکست در این مسیر همراه و همگام شماست تا بتوانید در فضای آنلاین کسب و کارهای خودتان را مدیریت کنید.","intro_footer":"با ما به آینده سفر کنید!"}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,61,223,970], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();